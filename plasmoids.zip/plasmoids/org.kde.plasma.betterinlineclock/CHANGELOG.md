2020/06/23 - version 3.1

* improved:
  - spacing option now changes all spaces including outer padding
  - option to disable calendar view borders

* fixed known bugs:
  - padding not pushing other widgets correctly, resulting in overlap
  - AM/PM label messing with padding additionally


2019/06/23 - version 2.0

* massive options overhaul
* added support for:
  - spacing of active labels
  - vertical & horizontal offset for the whole clock
  - gain back control by choosing fixed or automatic font size
  - font size can be manually set when fixed is chosen  
  
* fixes known bugs:
  - labels now show inline under all circumstances
  - separator can now be activated or deactivated as intended
